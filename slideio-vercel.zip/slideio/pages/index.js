import Head from 'next/head';
import Game from '../components/Game';

export default function Home() {
  return (
    <>
      <Head>
        <title>SLIDE.IO — Casual Puzzle Game</title>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta name="description" content="SLIDE.IO — A casual sliding tile puzzle game with daily challenges, leaderboards and themes." />
      </Head>
      <Game />
    </>
  );
}
