# 🎮 SLIDE.IO — Casual Puzzle Game

A full-featured sliding tile puzzle game built with Next.js.

---

## ✅ Features

- 🟢🟡🔴 Easy / Medium / Hard difficulty (3×3, 4×4, 5×5 grids)
- 📅 Daily Challenge (unique puzzle every day)
- 💡 Hint system
- 🎨 4 premium visual themes (Neon, Cyber, Sakura, Gold)
- 🖼️ Image tile mode with color themes
- 🔊 Sound effects
- 🏆 Leaderboard
- 👾 User profile with stats & win streaks
- 🎉 Confetti win celebration

---

## 🚀 How to Deploy on Vercel (Step by Step)

### Step 1 — Upload to GitHub

1. Go to [github.com](https://github.com) and create a free account
2. Click the **"+"** button → **New repository**
3. Name it `slideio` and click **Create repository**
4. Click **"uploading an existing file"**
5. Drag and drop the entire `slideio` project folder contents
6. Click **Commit changes**

### Step 2 — Deploy on Vercel

1. Go to [vercel.com](https://vercel.com) and click **Sign Up**
2. Choose **Continue with GitHub** — this links your accounts
3. Click **"Add New Project"**
4. Find your `slideio` repo and click **Import**
5. Leave all settings as default — Vercel auto-detects Next.js
6. Click **Deploy** 🚀

### Step 3 — Get your live link

- In ~60 seconds your game is live at: `your-project.vercel.app`
- Every time you update code on GitHub, Vercel auto-redeploys!

---

## 💳 Adding a Paywall (Optional)

To charge players, use **Stripe**:

1. Create account at [stripe.com](https://stripe.com)
2. Get your API keys from the Stripe dashboard
3. Add a "Pro" screen to the game that links to a Stripe payment page
4. After payment, Stripe redirects back to your game with a session token

Recommended stack for full auth + payments:
- **Clerk** (clerk.com) for user accounts
- **Stripe** (stripe.com) for payments
- **Vercel** for hosting

---

## 🛠️ Local Development

```bash
# Install dependencies
npm install

# Run locally
npm run dev

# Open in browser
http://localhost:3000
```

---

## 📁 Project Structure

```
slideio/
├── pages/
│   ├── _app.js        # App wrapper
│   ├── _document.js   # HTML head
│   └── index.js       # Home page
├── components/
│   └── Game.js        # Main game (all logic + UI)
├── styles/
│   └── globals.css    # Global styles + animations
├── public/            # Static assets (favicon etc.)
├── next.config.js
├── package.json
└── README.md
```

---

## 📬 Need help?

Ask Claude to help you add:
- Real user auth with Clerk
- Stripe payment integration
- A backend database for global leaderboards
- Mobile app version with React Native
