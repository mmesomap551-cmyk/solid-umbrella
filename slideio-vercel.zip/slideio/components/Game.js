import { useState, useEffect, useCallback, useRef } from 'react';

// ─── UTILITIES ────────────────────────────────────────────────────────────────
const CONFIGS = {
  3: { size: 3, label: 'Easy',   emoji: '🟢' },
  4: { size: 4, label: 'Medium', emoji: '🟡' },
  5: { size: 5, label: 'Hard',   emoji: '🔴' },
};

function makeSolved(n) {
  return Array.from({ length: n * n }, (_, i) => (i + 1) % (n * n));
}

function shuffle(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function isSolvable(tiles, n) {
  const flat = tiles.filter(t => t !== 0);
  let inv = 0;
  for (let i = 0; i < flat.length; i++)
    for (let j = i + 1; j < flat.length; j++)
      if (flat[i] > flat[j]) inv++;
  if (n % 2 === 1) return inv % 2 === 0;
  const blankRow = Math.floor(tiles.indexOf(0) / n);
  return (inv + blankRow) % 2 === 1;
}

function genSolvable(n) {
  let t;
  do { t = shuffle(makeSolved(n)); } while (!isSolvable(t, n));
  return t;
}

function isSolved(tiles, n) {
  return tiles.every((t, i) => t === (i + 1) % (n * n));
}

function fmt(s) {
  return `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;
}

function calcScore(moves, time) {
  return Math.max(0, 10000 - moves * 10 - time * 2);
}

// ─── SOUND ENGINE ─────────────────────────────────────────────────────────────
function useSound(enabled) {
  const ctx = useRef(null);
  return useCallback((type) => {
    if (!enabled) return;
    try {
      if (!ctx.current) ctx.current = new (window.AudioContext || window.webkitAudioContext)();
      const ac = ctx.current;
      const o = ac.createOscillator();
      const g = ac.createGain();
      o.connect(g); g.connect(ac.destination);
      if (type === 'move') {
        o.frequency.value = 440; o.type = 'sine';
        g.gain.setValueAtTime(0.1, ac.currentTime);
        g.gain.exponentialRampToValueAtTime(0.001, ac.currentTime + 0.08);
      } else if (type === 'win') {
        o.frequency.value = 523; o.type = 'triangle';
        g.gain.setValueAtTime(0.2, ac.currentTime);
        o.frequency.exponentialRampToValueAtTime(1047, ac.currentTime + 0.4);
        g.gain.exponentialRampToValueAtTime(0.001, ac.currentTime + 0.5);
      } else if (type === 'hint') {
        o.frequency.value = 330; o.type = 'sawtooth';
        g.gain.setValueAtTime(0.05, ac.currentTime);
        g.gain.exponentialRampToValueAtTime(0.001, ac.currentTime + 0.15);
      }
      o.start(); o.stop(ac.currentTime + 0.6);
    } catch (_) {}
  }, [enabled]);
}

// ─── HINT ENGINE ──────────────────────────────────────────────────────────────
function getHint(tiles, n) {
  let best = null, bestDist = Infinity;
  tiles.forEach((t, i) => {
    if (t === 0) return;
    const goalIdx = t - 1;
    const dr = Math.abs(Math.floor(i / n) - Math.floor(goalIdx / n));
    const dc = Math.abs((i % n) - (goalIdx % n));
    if (dr + dc < bestDist) { bestDist = dr + dc; best = i; }
  });
  return best;
}

// ─── IMAGE THEMES ─────────────────────────────────────────────────────────────
const IMAGE_THEMES = [
  { id: 'gradient', label: 'Gradient', colors: ['#f72585','#7209b7','#3a0ca3','#4361ee','#4cc9f0','#06d6a0','#ffd166','#ef476f','#118ab2','#073b4c','#f8961e','#577590','#43aa8b','#90be6d','#f9c74f','#f94144','#264653','#2a9d8f','#e9c46a','#f4a261','#e76f51','#d62828','#023e8a','#48cae4','#0077b6'] },
  { id: 'ocean',    label: 'Ocean',    colors: ['#03045e','#023e8a','#0077b6','#0096c7','#00b4d8','#48cae4','#90e0ef','#ade8f4','#caf0f8','#03045e','#023e8a','#0077b6','#0096c7','#00b4d8','#48cae4','#90e0ef','#ade8f4','#caf0f8','#03045e','#023e8a','#0077b6','#0096c7','#00b4d8','#48cae4','#0096c7'] },
  { id: 'forest',   label: 'Forest',   colors: ['#1b4332','#2d6a4f','#40916c','#52b788','#74c69d','#95d5b2','#b7e4c7','#d8f3dc','#081c15','#1b4332','#2d6a4f','#40916c','#52b788','#74c69d','#95d5b2','#b7e4c7','#d8f3dc','#081c15','#1b4332','#2d6a4f','#40916c','#52b788','#74c69d','#95d5b2','#40916c'] },
  { id: 'fire',     label: 'Fire',     colors: ['#03071e','#370617','#6a040f','#9d0208','#d00000','#dc2f02','#e85d04','#f48c06','#faa307','#03071e','#370617','#6a040f','#9d0208','#d00000','#dc2f02','#e85d04','#f48c06','#faa307','#03071e','#370617','#6a040f','#9d0208','#d00000','#faa307','#e85d04'] },
];

// ─── PREMIUM THEMES ───────────────────────────────────────────────────────────
const PREMIUM_THEMES = [
  { id: 'neon',   label: 'Neon',   bg: 'linear-gradient(135deg,#0d0221,#1a0533)', tile: '#2d1b69', accent: '#f72585', text: '#e0aaff' },
  { id: 'cyber',  label: 'Cyber',  bg: 'linear-gradient(135deg,#000d1a,#001f3f)', tile: '#003366', accent: '#00f5ff', text: '#00f5ff' },
  { id: 'sakura', label: 'Sakura', bg: 'linear-gradient(135deg,#2d1b2e,#1a0a1a)', tile: '#6b2d6b', accent: '#ff69b4', text: '#ffb3d9' },
  { id: 'gold',   label: 'Gold',   bg: 'linear-gradient(135deg,#1a1200,#2d2000)', tile: '#4a3800', accent: '#ffd700', text: '#ffe566' },
];

// ─── DAILY CHALLENGE ──────────────────────────────────────────────────────────
function getDailySeed() {
  const d = new Date();
  return `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`;
}

function seededRand(seed, index) {
  let h = index * 2654435761;
  for (let i = 0; i < seed.length; i++) h = Math.imul(h ^ seed.charCodeAt(i), 0x9e3779b9);
  h ^= h >>> 16; h = Math.imul(h, 0x45d9f3b); h ^= h >>> 16;
  return (h >>> 0) / 0xffffffff;
}

function getDailyPuzzle() {
  const seed = getDailySeed();
  let t;
  let attempt = 0;
  do {
    t = [...makeSolved(3)];
    for (let i = t.length - 1; i > 0; i--) {
      const j = Math.floor(seededRand(seed, i + attempt * 100) * (i + 1));
      [t[i], t[j]] = [t[j], t[i]];
    }
    attempt++;
  } while (!isSolvable(t, 3));
  return t;
}

// ─── FAKE LEADERBOARD ─────────────────────────────────────────────────────────
const INITIAL_LB = [
  { name: 'PuzzleMaster', score: 9420, moves: 28, time: 45 },
  { name: 'SlideKing',    score: 8980, moves: 32, time: 55 },
  { name: 'TilePro',      score: 8750, moves: 35, time: 60 },
  { name: 'QuickSolver',  score: 8500, moves: 38, time: 65 },
  { name: 'PuzzleNinja',  score: 8200, moves: 42, time: 72 },
];

const TILE_EMOJIS = ['🌊','🔥','🌿','✨','💎','🎯','🎪','🎭','🎨','🎲','🎸','🎺','🎻','🥁','🎹','🎮','🚀','🦄','🌈','🍀','⚡','🎃','🦋','🌸','🔮'];

// ─── NAV BUTTON STYLE ─────────────────────────────────────────────────────────
const navBtnStyle = {
  padding: '6px 14px', borderRadius: 8,
  background: 'rgba(255,255,255,0.08)',
  border: '1px solid rgba(255,255,255,0.1)',
  color: '#fff', cursor: 'pointer', fontSize: 12, fontWeight: 700,
};

// ─── SHARED COMPONENTS ────────────────────────────────────────────────────────
function Wrap({ theme, children }) {
  return (
    <div style={{ minHeight: '100vh', background: theme.bg, fontFamily: "'Courier New', monospace", display: 'flex', flexDirection: 'column', alignItems: 'center', padding: '24px 16px', color: theme.text }}>
      {children}
    </div>
  );
}

function Btn({ children, onClick, accent, secondary, disabled }) {
  return (
    <button onClick={onClick} disabled={disabled} style={{
      padding: '10px 20px', borderRadius: 10,
      background: secondary ? 'rgba(255,255,255,0.07)' : `linear-gradient(135deg, ${accent}, ${accent}bb)`,
      border: secondary ? `1px solid ${accent}44` : 'none',
      color: secondary ? accent : '#fff',
      fontWeight: 700, fontSize: 13, cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.4 : 1, letterSpacing: 1,
    }}>
      {children}
    </button>
  );
}

function Confetti({ accent }) {
  const pieces = Array.from({ length: 30 }, (_, i) => i);
  return (
    <div style={{ position: 'fixed', top: 0, left: 0, width: '100%', height: '100%', pointerEvents: 'none', zIndex: 999 }}>
      {pieces.map(i => (
        <div key={i} style={{
          position: 'absolute',
          left: `${Math.random() * 100}%`,
          top: '-10px',
          width: 8, height: 8,
          borderRadius: Math.random() > 0.5 ? '50%' : 2,
          background: [accent, '#fff', '#ffd700', '#ff69b4'][i % 4],
          animation: `confetti ${1 + Math.random() * 2}s ${Math.random() * 0.5}s ease-in forwards`,
        }} />
      ))}
    </div>
  );
}

// ─── MAIN APP ────────────────────────────────────────────────────────────────
export default function App() {
  const [screen, setScreen]         = useState('home');
  const [gridN, setGridN]           = useState(3);
  const [tiles, setTiles]           = useState(() => genSolvable(3));
  const [moves, setMoves]           = useState(0);
  const [time, setTime]             = useState(0);
  const [running, setRunning]       = useState(false);
  const [won, setWon]               = useState(false);
  const [soundOn, setSoundOn]       = useState(true);
  const [hintTile, setHintTile]     = useState(null);
  const [hintsLeft, setHintsLeft]   = useState(3);
  const [theme, setTheme]           = useState(PREMIUM_THEMES[0]);
  const [imgTheme, setImgTheme]     = useState(IMAGE_THEMES[0]);
  const [imageMode, setImageMode]   = useState(false);
  const [bestScores, setBestScores] = useState({ 3: null, 4: null, 5: null });
  const [userName, setUserName]     = useState('Player');
  const [editingName, setEditingName] = useState(false);
  const [tempName, setTempName]     = useState('Player');
  const [leaderboard, setLeaderboard] = useState(INITIAL_LB);
  const [dailyDone, setDailyDone]   = useState(false);
  const [dailyScore, setDailyScore] = useState(null);
  const [winStreak, setWinStreak]   = useState(0);
  const [totalWins, setTotalWins]   = useState(0);
  const [showConfetti, setShowConfetti] = useState(false);
  const [isDaily, setIsDaily]       = useState(false);

  const play = useSound(soundOn);

  useEffect(() => {
    if (!running) return;
    const id = setInterval(() => setTime(t => t + 1), 1000);
    return () => clearInterval(id);
  }, [running]);

  useEffect(() => {
    if (!hintTile) return;
    const id = setTimeout(() => setHintTile(null), 1500);
    return () => clearTimeout(id);
  }, [hintTile]);

  useEffect(() => {
    if (!showConfetti) return;
    const id = setTimeout(() => setShowConfetti(false), 3000);
    return () => clearTimeout(id);
  }, [showConfetti]);

  const startGame = (n) => {
    setGridN(n); setTiles(genSolvable(n));
    setMoves(0); setTime(0); setRunning(false);
    setWon(false); setHintsLeft(3); setHintTile(null);
    setIsDaily(false); setScreen('game');
  };

  const startDaily = () => {
    setGridN(3); setTiles(getDailyPuzzle());
    setMoves(0); setTime(0); setRunning(false);
    setWon(false); setHintsLeft(1); setHintTile(null);
    setIsDaily(true); setScreen('game');
  };

  const moveTile = (index) => {
    if (won) return;
    const blank = tiles.indexOf(0);
    const row = i => Math.floor(i / gridN);
    const col = i => i % gridN;
    const adj =
      (row(index) === row(blank) && Math.abs(col(index) - col(blank)) === 1) ||
      (col(index) === col(blank) && Math.abs(row(index) - row(blank)) === 1);
    if (!adj) return;
    if (!running) setRunning(true);
    const next = [...tiles];
    [next[index], next[blank]] = [next[blank], next[index]];
    setTiles(next);
    const newMoves = moves + 1;
    setMoves(newMoves);
    play('move');
    if (isSolved(next, gridN)) {
      setRunning(false); setWon(true); setShowConfetti(true);
      play('win');
      const s = calcScore(newMoves, time);
      if (isDaily) { setDailyDone(true); setDailyScore(s); }
      setTotalWins(w => w + 1);
      setWinStreak(w => w + 1);
      setBestScores(prev => {
        const cur = prev[gridN];
        if (!cur || s > cur.score) {
          setLeaderboard(lb =>
            [...lb, { name: userName, score: s, moves: newMoves, time }]
              .sort((a, b) => b.score - a.score).slice(0, 10)
          );
          return { ...prev, [gridN]: { score: s, moves: newMoves, time } };
        }
        return prev;
      });
    }
  };

  const useHint = () => {
    if (hintsLeft <= 0 || won) return;
    setHintTile(getHint(tiles, gridN));
    setHintsLeft(l => l - 1);
    play('hint');
  };

  const tileSize = gridN === 3 ? 82 : gridN === 4 ? 66 : 54;

  // ─── NAVBAR ───────────────────────────────────────────────────────────────
  const Navbar = () => (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', width: '100%', maxWidth: 460, marginBottom: 20 }}>
      {screen !== 'home'
        ? <button onClick={() => setScreen('home')} style={navBtnStyle}>← Back</button>
        : <div style={{ width: 70 }} />}
      <span style={{ fontSize: 20, fontWeight: 900, letterSpacing: 6, background: `linear-gradient(90deg, ${theme.accent}, #fff)`, WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>SLIDE.IO</span>
      <button onClick={() => setSoundOn(s => !s)} style={navBtnStyle}>{soundOn ? '🔊' : '🔇'}</button>
    </div>
  );

  // ─── HOME ─────────────────────────────────────────────────────────────────
  if (screen === 'home') return (
    <Wrap theme={theme}>
      <Navbar />
      {/* Profile */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, background: 'rgba(255,255,255,0.05)', border: `1px solid ${theme.accent}33`, borderRadius: 14, padding: '10px 16px', width: '100%', maxWidth: 460, marginBottom: 16 }}>
        <div style={{ width: 40, height: 40, borderRadius: '50%', background: `linear-gradient(135deg, ${theme.accent}, #fff2)`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 20 }}>👾</div>
        <div>
          <div style={{ fontWeight: 800, fontSize: 14, color: theme.text }}>{userName}</div>
          <div style={{ fontSize: 11, opacity: 0.5 }}>🏆 {totalWins} wins · 🔥 {winStreak} streak</div>
        </div>
        <button onClick={() => setScreen('account')} style={{ marginLeft: 'auto', ...navBtnStyle }}>Edit</button>
      </div>

      {/* Daily Challenge */}
      <div onClick={startDaily} style={{ width: '100%', maxWidth: 460, background: `linear-gradient(135deg, ${theme.accent}22, ${theme.accent}08)`, border: `1px solid ${theme.accent}66`, borderRadius: 16, padding: '14px 20px', marginBottom: 16, cursor: 'pointer', position: 'relative', overflow: 'hidden' }}>
        <div style={{ fontSize: 11, letterSpacing: 3, opacity: 0.6, textTransform: 'uppercase' }}>Daily Challenge</div>
        <div style={{ fontWeight: 900, fontSize: 18, color: theme.accent }}>Today's Puzzle ✦</div>
        <div style={{ fontSize: 12, opacity: 0.6 }}>{dailyDone ? `✅ Done! Score: ${dailyScore}` : 'New puzzle every day · 1 hint only'}</div>
        <div style={{ position: 'absolute', right: 16, top: '50%', transform: 'translateY(-50%)', fontSize: 32, opacity: 0.15 }}>📅</div>
      </div>

      {/* Difficulty */}
      <div style={{ width: '100%', maxWidth: 460, marginBottom: 16 }}>
        <div style={{ fontSize: 11, letterSpacing: 3, opacity: 0.5, marginBottom: 8, textTransform: 'uppercase' }}>Choose Difficulty</div>
        <div style={{ display: 'flex', gap: 8 }}>
          {Object.values(CONFIGS).map(c => (
            <button key={c.size} onClick={() => startGame(c.size)} style={{ flex: 1, padding: '14px 8px', borderRadius: 12, background: 'rgba(255,255,255,0.06)', border: `1px solid ${theme.accent}33`, color: theme.text, cursor: 'pointer', fontWeight: 700, fontSize: 13 }}>
              <div style={{ fontSize: 20 }}>{c.emoji}</div>
              <div>{c.label}</div>
              <div style={{ fontSize: 10, opacity: 0.5 }}>{c.size}×{c.size}</div>
              {bestScores[c.size] && <div style={{ fontSize: 10, color: theme.accent, marginTop: 2 }}>Best: {bestScores[c.size].score}</div>}
            </button>
          ))}
        </div>
      </div>

      {/* Nav */}
      <div style={{ display: 'flex', gap: 8, width: '100%', maxWidth: 460 }}>
        {[['🏆', 'Leaderboard', 'leaderboard'], ['🎨', 'Themes', 'themes']].map(([icon, label, s]) => (
          <button key={s} onClick={() => setScreen(s)} style={{ flex: 1, padding: '12px 8px', borderRadius: 12, background: 'rgba(255,255,255,0.05)', border: `1px solid ${theme.accent}22`, color: theme.text, cursor: 'pointer', fontSize: 13, fontWeight: 700 }}>
            <div style={{ fontSize: 22 }}>{icon}</div>{label}
          </button>
        ))}
      </div>
    </Wrap>
  );

  // ─── GAME ─────────────────────────────────────────────────────────────────
  if (screen === 'game') return (
    <Wrap theme={theme}>
      <Navbar />
      {showConfetti && <Confetti accent={theme.accent} />}

      {/* Stats */}
      <div style={{ display: 'flex', gap: 20, marginBottom: 16, background: 'rgba(255,255,255,0.05)', borderRadius: 12, padding: '10px 24px', border: `1px solid ${theme.accent}22` }}>
        {[['MOVES', moves], ['TIME', fmt(time)], ['SCORE', running || won ? calcScore(moves, time) : '—']].map(([l, v]) => (
          <div key={l} style={{ textAlign: 'center' }}>
            <div style={{ fontSize: 9, letterSpacing: 3, opacity: 0.5 }}>{l}</div>
            <div style={{ fontSize: 20, fontWeight: 800, color: theme.accent }}>{v}</div>
          </div>
        ))}
      </div>

      {/* Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: `repeat(${gridN}, 1fr)`, gap: 5, background: `${theme.accent}11`, borderRadius: 16, padding: 10, border: `1px solid ${theme.accent}22`, marginBottom: 16, boxShadow: `0 0 40px ${theme.accent}22` }}>
        {tiles.map((tile, i) => (
          <button key={i} onClick={() => moveTile(i)} style={{
            width: tileSize, height: tileSize, borderRadius: 10,
            border: tile === 0 ? 'none' : hintTile === i ? `2px solid ${theme.accent}` : `1px solid ${theme.accent}33`,
            background: tile === 0 ? 'rgba(0,0,0,0.15)' : imageMode ? imgTheme.colors[(tile - 1) % imgTheme.colors.length] : `linear-gradient(135deg, ${theme.tile}cc, ${theme.tile}88)`,
            color: theme.text,
            fontSize: gridN === 3 ? 24 : gridN === 4 ? 18 : 14,
            fontWeight: 900,
            cursor: tile === 0 ? 'default' : 'pointer',
            transition: 'all 0.1s ease',
            boxShadow: hintTile === i ? `0 0 16px ${theme.accent}` : tile === 0 ? 'none' : '0 2px 6px rgba(0,0,0,0.3)',
            transform: hintTile === i ? 'scale(1.05)' : 'scale(1)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            {tile === 0 ? '' : imageMode
              ? <span style={{ fontSize: gridN === 3 ? 28 : 20 }}>{TILE_EMOJIS[(tile - 1) % TILE_EMOJIS.length]}</span>
              : tile}
          </button>
        ))}
      </div>

      {/* Win Banner */}
      {won && (
        <div style={{ background: `linear-gradient(135deg, ${theme.accent}33, ${theme.accent}11)`, border: `1px solid ${theme.accent}`, borderRadius: 14, padding: '14px 24px', textAlign: 'center', marginBottom: 16, animation: 'popIn 0.4s cubic-bezier(.34,1.56,.64,1)' }}>
          <div style={{ fontSize: 32 }}>🎉</div>
          <div style={{ fontWeight: 900, fontSize: 18, color: theme.accent }}>SOLVED!</div>
          <div style={{ fontSize: 13, opacity: 0.8 }}>{moves} moves · {fmt(time)} · Score: {calcScore(moves, time)}</div>
          {isDaily && <div style={{ fontSize: 12, color: theme.accent, marginTop: 4 }}>Daily Challenge Complete! ✦</div>}
        </div>
      )}

      {/* Controls */}
      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', justifyContent: 'center' }}>
        <Btn accent={theme.accent} onClick={() => startGame(gridN)}>🔀 New Game</Btn>
        <Btn accent={theme.accent} onClick={useHint} disabled={hintsLeft <= 0 || won} secondary>💡 Hint ({hintsLeft})</Btn>
        <Btn accent={theme.accent} onClick={() => setImageMode(m => !m)} secondary>{imageMode ? '🔢 Numbers' : '🎨 Image'}</Btn>
      </div>
      {isDaily && !won && <div style={{ marginTop: 10, fontSize: 12, opacity: 0.5 }}>Daily Challenge · {hintsLeft} hint remaining</div>}
    </Wrap>
  );

  // ─── LEADERBOARD ──────────────────────────────────────────────────────────
  if (screen === 'leaderboard') return (
    <Wrap theme={theme}>
      <Navbar />
      <div style={{ width: '100%', maxWidth: 460 }}>
        <div style={{ fontSize: 11, letterSpacing: 4, opacity: 0.5, textAlign: 'center', marginBottom: 16, textTransform: 'uppercase' }}>Global Leaderboard 🏆</div>
        {leaderboard.map((entry, i) => (
          <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '12px 16px', marginBottom: 8, borderRadius: 12, background: entry.name === userName ? `${theme.accent}22` : 'rgba(255,255,255,0.04)', border: `1px solid ${entry.name === userName ? theme.accent + '66' : 'rgba(255,255,255,0.07)'}` }}>
            <div style={{ width: 32, height: 32, borderRadius: '50%', background: i === 0 ? '#ffd700' : i === 1 ? '#c0c0c0' : i === 2 ? '#cd7f32' : `${theme.accent}33`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 900, fontSize: 13, color: i < 3 ? '#000' : theme.text }}>{i + 1}</div>
            <div style={{ flex: 1 }}>
              <div style={{ fontWeight: 700, fontSize: 14 }}>{entry.name} {entry.name === userName && '⭐'}</div>
              <div style={{ fontSize: 11, opacity: 0.5 }}>{entry.moves} moves · {fmt(entry.time)}</div>
            </div>
            <div style={{ fontWeight: 900, fontSize: 16, color: theme.accent }}>{entry.score}</div>
          </div>
        ))}
        <div style={{ textAlign: 'center', marginTop: 16 }}>
          <div style={{ fontSize: 11, opacity: 0.4 }}>Your best scores:</div>
          {Object.entries(bestScores).map(([n, b]) => b && (
            <div key={n} style={{ fontSize: 13, color: theme.accent }}>{n}×{n}: {b.score} pts ({b.moves} moves)</div>
          ))}
        </div>
      </div>
    </Wrap>
  );

  // ─── THEMES ───────────────────────────────────────────────────────────────
  if (screen === 'themes') return (
    <Wrap theme={theme}>
      <Navbar />
      <div style={{ width: '100%', maxWidth: 460 }}>
        <div style={{ fontSize: 11, letterSpacing: 4, opacity: 0.5, textAlign: 'center', marginBottom: 16, textTransform: 'uppercase' }}>Premium Themes 🎨</div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 20 }}>
          {PREMIUM_THEMES.map(t => (
            <button key={t.id} onClick={() => setTheme(t)} style={{ padding: 16, borderRadius: 14, background: t.bg, border: `2px solid ${theme.id === t.id ? t.accent : 'transparent'}`, cursor: 'pointer', color: t.text, fontWeight: 800, fontSize: 14, textAlign: 'left', position: 'relative' }}>
              <div style={{ width: 28, height: 28, borderRadius: 8, background: t.accent, marginBottom: 8 }} />
              {t.label}
              {theme.id === t.id && <span style={{ position: 'absolute', top: 8, right: 10, fontSize: 16 }}>✓</span>}
            </button>
          ))}
        </div>
        <div style={{ fontSize: 11, letterSpacing: 4, opacity: 0.5, textAlign: 'center', marginBottom: 12, textTransform: 'uppercase' }}>Image Tile Themes</div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
          {IMAGE_THEMES.map(t => (
            <button key={t.id} onClick={() => { setImgTheme(t); setImageMode(true); }} style={{ padding: 12, borderRadius: 12, border: `2px solid ${imgTheme.id === t.id && imageMode ? theme.accent : 'rgba(255,255,255,0.1)'}`, background: 'rgba(255,255,255,0.04)', cursor: 'pointer', color: theme.text, fontWeight: 700 }}>
              <div style={{ display: 'flex', gap: 3, marginBottom: 6 }}>{t.colors.slice(0, 4).map((c, i) => <div key={i} style={{ flex: 1, height: 16, borderRadius: 4, background: c }} />)}</div>
              {t.label}
            </button>
          ))}
        </div>
      </div>
    </Wrap>
  );

  // ─── ACCOUNT ──────────────────────────────────────────────────────────────
  if (screen === 'account') return (
    <Wrap theme={theme}>
      <Navbar />
      <div style={{ width: '100%', maxWidth: 460 }}>
        <div style={{ textAlign: 'center', marginBottom: 24 }}>
          <div style={{ width: 80, height: 80, borderRadius: '50%', background: `linear-gradient(135deg, ${theme.accent}, #fff2)`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 40, margin: '0 auto 12px' }}>👾</div>
          {editingName ? (
            <div style={{ display: 'flex', gap: 8, justifyContent: 'center' }}>
              <input value={tempName} onChange={e => setTempName(e.target.value)} style={{ padding: '8px 12px', borderRadius: 10, background: 'rgba(255,255,255,0.1)', border: `1px solid ${theme.accent}`, color: theme.text, fontSize: 16, fontWeight: 700, outline: 'none', textAlign: 'center' }} />
              <button onClick={() => { setUserName(tempName); setEditingName(false); }} style={{ padding: '8px 16px', borderRadius: 10, background: theme.accent, border: 'none', color: '#fff', fontWeight: 700, cursor: 'pointer' }}>Save</button>
            </div>
          ) : (
            <div>
              <div style={{ fontSize: 22, fontWeight: 900, color: theme.text }}>{userName}</div>
              <button onClick={() => { setEditingName(true); setTempName(userName); }} style={{ ...navBtnStyle, marginTop: 8 }}>✏️ Edit Name</button>
            </div>
          )}
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 10, marginBottom: 20 }}>
          {[['🏆', 'Total Wins', totalWins], ['🔥', 'Win Streak', winStreak], ['📅', 'Daily Done', dailyDone ? 'Yes!' : 'No']].map(([icon, label, val]) => (
            <div key={label} style={{ padding: 14, borderRadius: 12, background: 'rgba(255,255,255,0.05)', border: `1px solid ${theme.accent}22`, textAlign: 'center' }}>
              <div style={{ fontSize: 24 }}>{icon}</div>
              <div style={{ fontSize: 18, fontWeight: 900, color: theme.accent }}>{val}</div>
              <div style={{ fontSize: 10, opacity: 0.5 }}>{label}</div>
            </div>
          ))}
        </div>
        <div style={{ fontSize: 12, opacity: 0.4, textAlign: 'center', marginBottom: 8 }}>Best Scores by Difficulty</div>
        {Object.entries(bestScores).map(([n, b]) => (
          <div key={n} style={{ display: 'flex', justifyContent: 'space-between', padding: '10px 0', borderBottom: '1px solid rgba(255,255,255,0.06)' }}>
            <span style={{ opacity: 0.7 }}>{n}×{n} Grid</span>
            <span style={{ color: theme.accent, fontWeight: 700 }}>{b ? `${b.score} pts` : '—'}</span>
          </div>
        ))}
      </div>
    </Wrap>
  );

  return null;
}
